package com.example.b2012015_calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    var lastNumeric: Boolean = false
    var lastDot: Boolean = false
    var lenght: Int = 0
    private var tvInput: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvInput = findViewById(R.id.tvInput)
        var btnZero = findViewById<Button>(R.id.btnZero)
        var btnOne = findViewById<Button>(R.id.btnOne)
        var btnTwo = findViewById<Button>(R.id.btnTwo)
        var btnThree = findViewById<Button>(R.id.btnThree)
        var btnFour = findViewById<Button>(R.id.btnFour)
        var btnFive = findViewById<Button>(R.id.btnFive)
        var btnSix = findViewById<Button>(R.id.btnSix)
        var btnSeven = findViewById<Button>(R.id.btnSeven)
        var btnEight = findViewById<Button>(R.id.btnEight)
        var btnNine = findViewById<Button>(R.id.btnNine)

        var btnAdd = findViewById<Button>(R.id.btnAdd)
        var btnSubtract = findViewById<Button>(R.id.btnSubtract)
        var btnMultiply = findViewById<Button>(R.id.btnMultiply)
        var btnDivide = findViewById<Button>(R.id.btnDivide)

        var btnDecimal = findViewById<Button>(R.id.btnDecimal)
        var btnClear = findViewById<Button>(R.id.btnClear)
        var btnEqual = findViewById<Button>(R.id.btnEqual)

        btnZero.setOnClickListener() {
            tvInput?.setText(tvInput?.text.toString() + "0")
            println("$tvInput!")
            lastNumeric = true
            lastDot = false
        }
        btnOne.setOnClickListener() {
            tvInput?.setText(tvInput?.text.toString() + "1")
            println("$tvInput")
            lastNumeric = true
            lastDot = false
        }
        btnTwo.setOnClickListener() {
            tvInput?.setText(tvInput?.text.toString() + "2")
            println("$tvInput")
            lastNumeric = true
            lastDot = false
        }
        btnThree.setOnClickListener() {
            tvInput?.setText(tvInput?.text.toString() + "3")
            println("$tvInput")
            lastNumeric = true
            lastDot = false
        }
        btnFour.setOnClickListener() {
            tvInput?.setText(tvInput?.text.toString() + "4")
            println("$tvInput")
            lastNumeric = true
            lastDot = false
        }
        btnFive.setOnClickListener() {
            tvInput?.setText(tvInput?.text.toString() + "5")
            println("$tvInput")
            lastNumeric = true
            lastDot = false
        }
        btnSix.setOnClickListener() {
            tvInput?.setText(tvInput?.text.toString() + "6")
            println("$tvInput")
            lastNumeric = true
            lastDot = false
        }
        btnSeven.setOnClickListener() {
            tvInput?.setText(tvInput?.text.toString() + "7")
            println("$tvInput")
            lastNumeric = true
            lastDot = false
        }
        btnEight.setOnClickListener() {
            tvInput?.setText(tvInput?.text.toString() + "8")
            println("$tvInput")
            lastNumeric = true
            lastDot = false
        }
        btnNine.setOnClickListener() {
            tvInput?.setText(tvInput?.text.toString() + "9")
            println("$tvInput")
            lastNumeric = true
            lastDot = false
        }

        btnAdd.setOnClickListener() {
            if (lastNumeric && !lastDot) {
                tvInput?.setText(tvInput?.text.toString() + "+")
                println("$tvInput")
                lastNumeric = false
                lastDot = true
            }
        }

        btnSubtract.setOnClickListener() {
            if (!lastDot) {
                tvInput?.setText(tvInput?.text.toString() + "-")
                println("$tvInput")
                lastNumeric = false
                lastDot = true
            }
        }
        btnMultiply.setOnClickListener() {
            if (lastNumeric && !lastDot) {
                tvInput?.setText(tvInput?.text.toString() + "*")
                lastNumeric = false
                lastDot = true
            }
        }
        btnDivide.setOnClickListener() {
            if (lastNumeric) {
                tvInput?.setText(tvInput?.text.toString() + "/")
                println("$tvInput")
                lastNumeric = false
                lastDot = true
            }
        }
        btnClear.setOnClickListener() {
            tvInput?.setText("")
            lastDot = false
            lastNumeric = false
        }
//Chấm
        btnDecimal.setOnClickListener() {
            if (lastNumeric && !lastNumeric) {
                tvInput?.setText(tvInput?.text.toString() + ".")
                println("$tvInput")
                lastDot = true
            }
        }
        btnEqual.setOnClickListener() {
            if (lastNumeric && !lastDot) {
                // Lấy chuỗi nhập từ TextView
                val inputValue = tvInput?.text.toString()
                var result = ""
                val isNegative = inputValue.startsWith("-") // -3
                val negMultiplier = if (isNegative) -1 else 1
                val cleanedInput = if (isNegative) inputValue.substring(1) else inputValue // 3
                Log.d("log1", inputValue)
                Log.d("log2", inputValue.substring(1)) // 3-3
                try {
                    val operators = listOf("+", "-", "*", "/")
                    val operator = operators.find { cleanedInput.contains(it) }
                    Log.d("log3", operator.toString())
                    if (operator != null) {
                        val splitValue = cleanedInput.split(operator)
                        val operand1 = negMultiplier * splitValue[0].toDouble()
                        val operand2 = splitValue[1].toDouble()
                        result = when (operator) {
                            "+" -> (operand1 + operand2).toString()
                            "-" -> (operand1 - operand2).toString()
                            "*" -> (operand1 * operand2).toString()
                            "/" -> if (operand2 != 0.0) (operand1 / operand2).toString() else "Biểu thức sai"
                            else -> ""
                        }
                    }

//                    result = removeZeroAfterDot(result)
                    tvInput?.text = result

                } catch (e: ArithmeticException) {
                    tvInput?.text = "Error"
                }
                lastNumeric = true
//            }
            }
        }
    }

}